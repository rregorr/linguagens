package com.ankiapp.repository;

import com.ankiapp.model.Resolucao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResolucaoRepository extends JpaRepository<Resolucao, Integer> {
}
