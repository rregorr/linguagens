package com.ankiapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnkiappApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnkiappApplication.class, args);
	}

}
